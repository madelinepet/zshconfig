# fd

This plugin adds completion for the file search tool [`fd`](https://github.com/sharkdp/fd), also known as `fd-find`.

To use it, add `fd` to the plugins array in your zshrc file:

```zsh
plugins=(... fd)
```
