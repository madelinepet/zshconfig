# Volta

This plugin provides completion for [Volta](https://volta.sh/).

To use it add volta to the plugins array in your zshrc file.

```bash
plugins=(... volta)
```

This plugin installs no aliases.
